#define UTS_RELEASE "2.6.35-32-server"
